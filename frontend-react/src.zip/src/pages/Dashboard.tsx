import { useQuery } from "@tanstack/react-query";
import AppLayout from "@/components/layout/AppLayout";
import StatusBadge from "@/components/StatusBadge";
import { dashboardApi, orderApi, vendorApi } from "@/lib/api";
import { mockDashboardStats, mockOrders, mockVendors } from "@/lib/mock-data";
import {
  TrendingUp,
  Users,
  ShoppingCart,
  CreditCard,
  Clock,
  DollarSign,
  Loader2,
} from "lucide-react";

export default function Dashboard() {
  // Dashboard API
  const { data: statsData, isLoading: statsLoading } = useQuery({
    queryKey: ["dashboard"],
    queryFn: dashboardApi.getStats,
    retry: 1,
  });

  // Orders API
  const { data: ordersData } = useQuery({
    queryKey: ["orders"],
    queryFn: orderApi.getAll,
    retry: 1,
  });

  // Vendors API
  const { data: vendorsData } = useQuery({
    queryKey: ["vendors"],
    queryFn: vendorApi.getAll,
    retry: 1,
  });

  // ✅ SAFE DATA FALLBACK
  const orders = ordersData || mockOrders;
  const vendors = vendorsData || mockVendors;

  const recentOrders = orders.slice(0, 5);
  const pendingVendors = vendors.filter((v) => v.status === "PENDING");

  // ✅ MAP BACKEND RESPONSE → UI MODEL
 const dashStats = statsData
  ? (() => {
      const vendorStatusMap = Object.fromEntries(
        (statsData.vendorStatus || []).map((v: any) => [v.status, v.value])
      );

      const paymentStatusMap = Object.fromEntries(
        (statsData.paymentStatus || []).map((p: any) => [p.status, p.value])
      );

      return {
        totalVendors: statsData.stats?.vendors ?? 0,
        activeVendors: vendorStatusMap["APPROVED"] ?? 0,
        pendingApprovals: vendorStatusMap["PENDING"] ?? 0,
        totalOrders: statsData.stats?.orders ?? 0,
        pendingPayments: paymentStatusMap["PENDING"] ?? 0,
        totalPaymentsAmount: statsData.stats?.payments ?? 0,
      };
    })()
  : mockDashboardStats;
  // ✅ STATS CONFIG
  const stats = [
    {
      label: "Total Vendors",
      value: dashStats.totalVendors,
      icon: Users,
      change: `${dashStats.activeVendors} active`,
    },
    {
      label: "Active Vendors",
      value: dashStats.activeVendors,
      icon: TrendingUp,
      change: `${Math.round(
        (dashStats.activeVendors / (dashStats.totalVendors || 1)) * 100
      )}% of total`,
    },
    {
      label: "Pending Approvals",
      value: dashStats.pendingApprovals,
      icon: Clock,
      change: "Requires action",
    },
    {
      label: "Total Orders",
      value: dashStats.totalOrders,
      icon: ShoppingCart,
      change: "All time",
    },
    {
      label: "Pending Payments",
      value: dashStats.pendingPayments,
      icon: CreditCard,
      change: "Awaiting clearance",
    },
    {
      label: "Total Paid",
      value: `$${(dashStats.totalPaymentsAmount ?? 0).toLocaleString()}`,
      icon: DollarSign,
      change: "This period",
    },
  ];

  return (
    <AppLayout title="Dashboard" subtitle="Overview of vendor management activities">
      {/* Loading Indicator */}
      {statsLoading && (
        <div className="flex items-center gap-2 mb-4 text-xs text-muted-foreground">
          <Loader2 size={14} className="animate-spin" /> Loading live data...
        </div>
      )}

      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4 mb-6">
        {stats.map((stat) => (
          <div key={stat.label} className="stat-card">
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
                {stat.label}
              </span>
              <stat.icon size={16} className="text-muted-foreground" />
            </div>
            <p className="text-2xl font-semibold text-foreground">
              {stat.value ?? 0}
            </p>
            <p className="text-xs text-muted-foreground mt-1">{stat.change}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent Orders */}
        <div className="lg:col-span-2 bg-card border border-border rounded-md">
          <div className="px-4 py-3 border-b border-border">
            <h2 className="text-sm font-semibold text-foreground">
              Recent Purchase Orders
            </h2>
          </div>
          <table className="data-table">
            <thead>
              <tr>
                <th>Order #</th>
                <th>Vendor</th>
                <th>Amount</th>
                <th>Status</th>
                <th>Date</th>
              </tr>
            </thead>
            <tbody>
              {recentOrders.map((order: any) => (
                <tr key={order.id}>
                  <td className="font-medium text-foreground">PO-{order.id}</td>
                  <td>{order.vendorName}</td>
                  <td>${(order.totalAmount ?? 0).toLocaleString()}</td>
                  <td>
                    <StatusBadge status={order.status} />
                  </td>
                  <td className="text-muted-foreground">{order.createdAt}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Pending Vendors */}
        <div className="bg-card border border-border rounded-md">
          <div className="px-4 py-3 border-b border-border">
            <h2 className="text-sm font-semibold text-foreground">
              Pending Vendor Approvals
            </h2>
          </div>
          <div className="p-4 space-y-3">
            {pendingVendors.length === 0 ? (
              <p className="text-sm text-muted-foreground">
                No pending approvals
              </p>
            ) : (
              pendingVendors.map((vendor: any) => (
                <div
                  key={vendor.id}
                  className="flex items-center justify-between p-3 bg-muted/50 rounded-md"
                >
                  <div>
                    <p className="text-sm font-medium text-foreground">
                      {vendor.companyName}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {vendor.contactPerson} · {vendor.email}
                    </p>
                  </div>
                  <StatusBadge status={vendor.status} />
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </AppLayout>
  );
}