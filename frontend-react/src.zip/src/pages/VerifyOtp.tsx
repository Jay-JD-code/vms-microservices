import { useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";

export default function VerifyOtp() {
  const [otp, setOtp] = useState("");
  const location = useLocation();
  const navigate = useNavigate();

  const email = location.state?.email;

  const handleVerify = async () => {
    try {
      const res = await fetch("http://localhost:8080/api/auth/verify-otp", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, otp }),
      });

      const resetToken = await res.text(); // 🔥 your backend returns string

      navigate("/reset-password", {
        state: { email, resetToken },
      });

    } catch {
      alert("Invalid OTP");
    }
  };

  return (
    <div className="flex h-screen items-center justify-center">
      <div className="p-6 bg-white rounded shadow w-80">
        <h2 className="mb-4">Verify OTP</h2>

        <input
          className="w-full border p-2 mb-4"
          placeholder="Enter OTP"
          value={otp}
          onChange={(e) => setOtp(e.target.value)}
        />

        <button
          onClick={handleVerify}
          className="w-full bg-green-500 text-white p-2"
        >
          Verify OTP
        </button>
      </div>
    </div>
  );
}