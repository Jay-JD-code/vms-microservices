import { useState, useRef } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import AppLayout from "@/components/layout/AppLayout";
import { documentApi, vendorApi } from "@/lib/api";
import { toast } from "sonner";

const DOC_TYPES = ["CONTRACT", "INSURANCE", "LICENSE", "TAX_FORM", "CERTIFICATE", "OTHER"];

export default function Documents() {
  const queryClient = useQueryClient();

  const [search, setSearch] = useState("");
  const [showUpload, setShowUpload] = useState(false);
  const [uploadVendorId, setUploadVendorId] = useState("");
  const [uploadDocType, setUploadDocType] = useState("CONTRACT");
  const [selectedVendor, setSelectedVendor] = useState<any | null>(null);

  const fileRef = useRef<HTMLInputElement>(null);

  const { data: documents = [] } = useQuery({
    queryKey: ["documents"],
    queryFn: documentApi.getAll,
  });

  const { data: vendors = [] } = useQuery({
    queryKey: ["vendors"],
    queryFn: vendorApi.getAll,
  });

  const approvedVendors = vendors.filter((v: any) => v.status === "APPROVED");

  //////////////////////////////////////////////////////
  // GROUP DOCUMENTS
  //////////////////////////////////////////////////////
  const grouped = Object.values(
    documents.reduce((acc: any, doc: any) => {
      const vendor = vendors.find((v: any) => v.id === doc.vendorId);

      const vendorName =
        doc.vendorName ||
        vendor?.companyName ||
        "Unknown Vendor";

      if (!acc[doc.vendorId]) {
        acc[doc.vendorId] = {
          vendorId: doc.vendorId,
          vendorName,
          documents: [],
        };
      }

      acc[doc.vendorId].documents.push(doc);
      return acc;
    }, {})
  ).filter((v: any) =>
    v.vendorName.toLowerCase().includes(search.toLowerCase())
  );

  //////////////////////////////////////////////////////
  // UPLOAD
  //////////////////////////////////////////////////////
  const uploadMutation = useMutation({
    mutationFn: async ({ file, vendorId, docType }: any) => {
      const { uploadUrl, fileKey } = await documentApi.getUploadUrl({
        fileName: file.name,
        contentType: file.type,
        vendorId,
        docType,
      });

      await fetch(uploadUrl, {
        method: "PUT",
        headers: { "Content-Type": file.type },
        body: file,
      });

      await documentApi.saveMetadata({
        vendorId,
        docType,
        fileName: file.name,
        fileKey,
      });
    },
    onSuccess: () => {
      toast.success("Document uploaded");

      queryClient.invalidateQueries({ queryKey: ["documents"] });

      // 🔥 IMPORTANT UX FIX
      setShowUpload(false);
      setSelectedVendor(null);
      setUploadVendorId("");
      if (fileRef.current) fileRef.current.value = "";
    },
  });

  //////////////////////////////////////////////////////
  // APPROVE / REJECT
  //////////////////////////////////////////////////////
  const approveMutation = useMutation({
    mutationFn: (id: string) => documentApi.approve(id),
    onSuccess: () => {
      toast.success("Approved");
      queryClient.invalidateQueries({ queryKey: ["documents"] });
    },
  });

  const rejectMutation = useMutation({
    mutationFn: (id: string) => documentApi.reject(id),
    onSuccess: () => {
      toast.success("Rejected");
      queryClient.invalidateQueries({ queryKey: ["documents"] });
    },
  });

  //////////////////////////////////////////////////////
  // HANDLERS
  //////////////////////////////////////////////////////
  const handleUpload = (e: any) => {
    e.preventDefault();
    const file = fileRef.current?.files?.[0];

    if (!file) return toast.error("Select file");
    if (!uploadVendorId) return toast.error("Select vendor");

    uploadMutation.mutate({
      file,
      vendorId: uploadVendorId,
      docType: uploadDocType,
    });
  };

  const handleDownload = async (id: number, fileName: string) => {
    const res = await documentApi.download(id);
    const blob = await res.blob();
    const url = URL.createObjectURL(blob);

    const a = document.createElement("a");
    a.href = url;
    a.download = fileName;
    a.click();
  };

  //////////////////////////////////////////////////////
  // UI
  //////////////////////////////////////////////////////
  return (
    <AppLayout title="Documents" subtitle="Vendor document management">

      {/* SEARCH + UPLOAD */}
      <div className="flex justify-between mb-6">
        <input
          placeholder="Search vendor..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="border px-3 py-2 rounded w-[250px]"
        />

        <button
          onClick={() => setShowUpload(true)}
          className="bg-primary text-white px-4 py-2 rounded"
        >
          Upload
        </button>
      </div>

      {/* VENDOR LIST */}
      {!selectedVendor && (
        <>
          {grouped.length === 0 ? (
            <div className="text-center text-gray-500 mt-10">
              No documents found
            </div>
          ) : (
            <div className="grid gap-4">
              {grouped.map((v: any) => (
                <div
                  key={v.vendorId}
                  onClick={() => setSelectedVendor(v)}
                  className="bg-white border rounded-lg p-4 shadow-sm cursor-pointer hover:shadow-md"
                >
                  <h3 className="font-semibold text-lg">{v.vendorName}</h3>
                  <p className="text-sm text-gray-500">
                    {v.documents.length} documents
                  </p>
                </div>
              ))}
            </div>
          )}
        </>
      )}

      {/* DOCUMENT VIEW */}
      {selectedVendor && (
        <div>

          <button
            onClick={() => setSelectedVendor(null)}
            className="mb-4 text-blue-600 text-sm hover:underline"
          >
            ← Back to Vendors
          </button>

          <div className="mb-4">
            <h2 className="text-xl font-semibold">
              {selectedVendor.vendorName}
            </h2>
            <p className="text-sm text-gray-500">
              {selectedVendor.documents.length} documents
            </p>
          </div>

          <div className="bg-white border rounded-lg shadow-sm overflow-hidden">
            <table className="w-full text-sm">
              <thead className="bg-gray-100 text-left">
                <tr>
                  <th className="p-3">File</th>
                  <th className="p-3">Type</th>
                  <th className="p-3">Status</th>
                  <th className="p-3">Actions</th>
                </tr>
              </thead>

              <tbody>
                {selectedVendor.documents.map((doc: any) => (
                  <tr key={doc.id} className="border-t hover:bg-gray-50">

                    <td className="p-3 font-medium">📄 {doc.fileName}</td>

                    <td className="p-3">{doc.documentType}</td>

                    <td className="p-3">
                      <span
                        className={`px-2 py-1 text-xs rounded ${
                          doc.status === "APPROVED"
                            ? "bg-green-100 text-green-700"
                            : doc.status === "REJECTED"
                            ? "bg-red-100 text-red-700"
                            : "bg-yellow-100 text-yellow-700"
                        }`}
                      >
                        {doc.status || "PENDING"}
                      </span>
                    </td>

                    <td className="p-3 flex gap-3">
                      <button
                        onClick={() => handleDownload(doc.id, doc.fileName)}
                        className="text-blue-600 text-xs"
                      >
                        Download
                      </button>

                      {doc.status === "PENDING" && (
                        <>
                          <button
                            onClick={() => approveMutation.mutate(doc.id)}
                            className="text-green-600 text-xs"
                          >
                            Approve
                          </button>

                          <button
                            onClick={() => rejectMutation.mutate(doc.id)}
                            className="text-red-600 text-xs"
                          >
                            Reject
                          </button>
                        </>
                      )}
                    </td>

                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* UPLOAD MODAL */}
      {showUpload && (
        <div
          className="fixed inset-0 bg-black/40 flex justify-center items-center"
          onClick={() => setShowUpload(false)} // 🔥 CLOSE ON OUTSIDE CLICK
        >
          <form
            className="bg-white p-5 rounded w-[400px]"
            onClick={(e) => e.stopPropagation()} // 🔥 PREVENT CLOSE INSIDE
            onSubmit={handleUpload}
          >
            <h3 className="mb-3 font-semibold">Upload Document</h3>

            <select
              value={uploadVendorId}
              onChange={(e) => setUploadVendorId(e.target.value)}
              className="border w-full p-2 mb-2"
            >
              <option value="">Select Vendor</option>
              {approvedVendors.map((v: any) => (
                <option key={v.id} value={v.id}>
                  {v.companyName}
                </option>
              ))}
            </select>

            <select
              value={uploadDocType}
              onChange={(e) => setUploadDocType(e.target.value)}
              className="border w-full p-2 mb-2"
            >
              {DOC_TYPES.map((t) => (
                <option key={t}>{t}</option>
              ))}
            </select>

            <input ref={fileRef} type="file" className="mb-3" />

            <button className="bg-primary text-white w-full py-2 rounded">
              Upload
            </button>
          </form>
        </div>
      )}
    </AppLayout>
  );
}