import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import AppLayout from "@/components/layout/AppLayout";
import StatusBadge from "@/components/StatusBadge";
import { paymentApi, orderApi } from "@/lib/api";
import { mockPayments, mockOrders } from "@/lib/mock-data";
import type { PaymentStatus } from "@/types";
import { useAuth } from "@/hooks/useAuth";
import { Search, Filter, Plus, Loader2 } from "lucide-react";
import { toast } from "sonner";

export default function Payments() {
  const { canProcessPayments } = useAuth();
  const queryClient = useQueryClient();
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<PaymentStatus | "ALL">("ALL");
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [newOrderId, setNewOrderId] = useState("");
  const [newAmount, setNewAmount] = useState("");
  const [newMethod, setNewMethod] = useState("BANK_TRANSFER");

  const { data: payments = mockPayments, isLoading } = useQuery({
    queryKey: ["payments"],
    queryFn: paymentApi.getAll,
    retry: 1,
  });

  const { data: orders = mockOrders } = useQuery({
    queryKey: ["orders"],
    queryFn: orderApi.getAll,
    retry: 1,
  });

  const createMutation = useMutation({
    mutationFn: (data: { orderId: number; amount: number; method: string }) => paymentApi.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["payments"] });
      toast.success("Payment created successfully");
      setShowCreateForm(false);
      setNewOrderId("");
      setNewAmount("");
    },
    onError: (err: any) => {
  const message =
    err?.response?.data?.message ||
    err?.message ||
    "Failed to create payment";

  toast.error(message);
},
  });

  const statusMutation = useMutation({
    mutationFn: ({ id, status }: { id: number; status: string }) => paymentApi.updateStatus(id, status),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["payments"] });
      toast.success("Payment status updated");
    },
    onError: (err: Error) => toast.error(err.message || "Failed to update payment"),
  });

  const handleCreatePayment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newOrderId || !newAmount) { toast.error("Fill all fields"); return; }
    createMutation.mutate({ orderId: Number(newOrderId), amount: Number(newAmount), method: newMethod });
  };

  const filtered = payments.filter((p) => {
    const matchSearch =
      p.vendorName?.toLowerCase().includes(search.toLowerCase()) ||
      String(p.orderId).includes(search);
    const matchStatus = statusFilter === "ALL" || p.status === statusFilter;
    return matchSearch && matchStatus;
  });

  const totalPending = payments.filter((p) => p.status === "PENDING").reduce((s, p) => s + p.amount, 0);
  const totalCompleted = payments.filter((p) => p.status === "COMPLETED").reduce((s, p) => s + p.amount, 0);

  return (
    <AppLayout title="Payments" subtitle="Manage vendor payments and invoices">
      {/* Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
        <div className="stat-card">
          <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-1">Total Pending</p>
          <p className="text-xl font-semibold text-warning">${totalPending.toLocaleString()}</p>
        </div>
        <div className="stat-card">
          <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-1">Total Completed</p>
          <p className="text-xl font-semibold text-success">${totalCompleted.toLocaleString()}</p>
        </div>
        <div className="stat-card">
          <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-1">Total Transactions</p>
          <p className="text-xl font-semibold text-foreground">{payments.length}</p>
        </div>
      </div>

      {/* Toolbar */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 mb-4">
        <div className="flex items-center gap-3">
          <div className="relative">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <input
              type="text"
              placeholder="Search by vendor or order..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="h-8 pl-9 pr-3 text-xs bg-card border border-input rounded-md w-56 focus:outline-none focus:ring-1 focus:ring-ring"
            />
          </div>
          <div className="flex items-center gap-1">
            <Filter size={14} className="text-muted-foreground" />
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value as PaymentStatus | "ALL")}
              className="h-8 px-2 text-xs bg-card border border-input rounded-md focus:outline-none focus:ring-1 focus:ring-ring"
            >
              <option value="ALL">All Status</option>
              <option value="PENDING">Pending</option>
              <option value="COMPLETED">Completed</option>
              <option value="FAILED">Failed</option>
            </select>
          </div>
        </div>
        {canProcessPayments && (
          <button
            onClick={() => setShowCreateForm(!showCreateForm)}
            className="flex items-center gap-1.5 h-8 px-3 bg-primary text-primary-foreground text-xs font-medium rounded-md hover:opacity-90 transition-opacity"
          >
            <Plus size={14} /> Record Payment
          </button>
        )}
      </div>

      {/* Create Payment Form */}
      {showCreateForm && (
        <form onSubmit={handleCreatePayment} className="bg-card border border-border rounded-md p-4 mb-4">
          <h3 className="text-sm font-semibold text-foreground mb-3">Record Payment</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-medium text-foreground mb-1">Order *</label>
              <select
                value={newOrderId}
                onChange={(e) => {
                  setNewOrderId(e.target.value);
                  const order = orders.find(o => o.id === Number(e.target.value));
                  if (order) setNewAmount(String(order.totalAmount));
                }}
                className="w-full h-8 px-3 text-xs bg-background border border-input rounded-md focus:outline-none focus:ring-1 focus:ring-ring"
                required
              >
                <option value="">Select order...</option>

{orders
  .filter(o => o.status === "DELIVERED")
  .map(o => (
    <option key={o.id} value={o.id}>
      PO-{o.id} — {o.vendorName} (${o.totalAmount})
    </option>
))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-foreground mb-1">Amount *</label>
              <input
                type="number"
                value={newAmount}
                onChange={(e) => setNewAmount(e.target.value)}
                className="w-full h-8 px-3 text-xs bg-background border border-input rounded-md focus:outline-none focus:ring-1 focus:ring-ring"
                min={0}
                step="0.01"
                required
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-foreground mb-1">Method</label>
              <select
                value={newMethod}
                onChange={(e) => setNewMethod(e.target.value)}
                className="w-full h-8 px-3 text-xs bg-background border border-input rounded-md focus:outline-none focus:ring-1 focus:ring-ring"
              >
                <option value="BANK_TRANSFER">Bank Transfer</option>
                <option value="CHECK">Check</option>
                <option value="CREDIT_CARD">Credit Card</option>
                <option value="WIRE">Wire</option>
              </select>
            </div>
          </div>
          <div className="flex gap-2 mt-3">
            <button type="submit" disabled={createMutation.isPending} className="h-8 px-4 bg-primary text-primary-foreground text-xs font-medium rounded-md hover:opacity-90 disabled:opacity-50">
              {createMutation.isPending ? "Submitting..." : "Submit Payment"}
            </button>
            <button type="button" onClick={() => setShowCreateForm(false)} className="h-8 px-4 bg-muted text-muted-foreground text-xs font-medium rounded-md hover:bg-muted/80">Cancel</button>
          </div>
        </form>
      )}

      {isLoading && (
        <div className="flex items-center justify-center py-12 text-muted-foreground">
          <Loader2 size={18} className="animate-spin mr-2" /> Loading payments...
        </div>
      )}

      {/* Payments Table */}
      {!isLoading && (
        <div className="bg-card border border-border rounded-md overflow-x-auto">
          <table className="data-table">
            <thead>
              <tr>
                <th>Payment #</th>
                <th>Order #</th>
                <th>Vendor</th>
                <th>Amount</th>
                <th>Method</th>
                <th>Status</th>
                <th>Date</th>
                {canProcessPayments && <th>Actions</th>}
              </tr>
            </thead>
            <tbody>
              {filtered.map((payment) => (
                <tr key={payment.id}>
                  <td className="font-medium text-foreground">PAY-{payment.id}</td>
                  <td>PO-{payment.orderId}</td>
                  <td>{payment.vendorName}</td>
                  <td className="font-medium">${payment.amount.toLocaleString()}</td>
                  <td className="text-muted-foreground text-xs">{payment.method.replace("_", " ")}</td>
                  <td><StatusBadge status={payment.status} /></td>
                  <td className="text-muted-foreground">{payment.createdAt}</td>
                  {canProcessPayments && (
                    <td>
                      {payment.status === "PENDING" && (
                        <div className="flex gap-1">
                          <button
                            onClick={() => statusMutation.mutate({ id: payment.id, status: "COMPLETED" })}
                            disabled={statusMutation.isPending}
                            className="text-[11px] px-2 py-0.5 rounded font-medium text-primary hover:bg-primary/10"
                          >
                            Complete
                          </button>
                          <button
                            onClick={() => statusMutation.mutate({ id: payment.id, status: "FAILED" })}
                            disabled={statusMutation.isPending}
                            className="text-[11px] px-2 py-0.5 rounded font-medium text-destructive hover:bg-destructive/10"
                          >
                            Fail
                          </button>
                        </div>
                      )}
                    </td>
                  )}
                </tr>
              ))}
              {filtered.length === 0 && (
                <tr>
                  <td colSpan={canProcessPayments ? 8 : 7} className="text-center text-muted-foreground py-8">No payments found.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      )}
    </AppLayout>
  );
}
