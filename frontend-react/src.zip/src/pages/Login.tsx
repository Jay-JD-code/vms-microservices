import { useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useNavigate } from "react-router-dom";
import type { UserRole } from "@/types";
import { ROLE_PERMISSIONS } from "@/types";

const ROLE_OPTIONS: { value: UserRole; label: string; description: string }[] = [
  { value: "ADMIN", label: "Administrator", description: "Full system access — manage all modules" },
  { value: "VENDOR", label: "Vendor", description: "View own orders, payments, docs & performance" },
  { value: "PROCUREMENT", label: "Procurement", description: "Manage vendors, orders & documents" },
  { value: "FINANCE", label: "Finance", description: "Manage payments & view orders" },
];

export default function Login() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState("admin@vms.com");
  const [password, setPassword] = useState("admin123");
  const [selectedRole, setSelectedRole] = useState<UserRole>("ADMIN");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

const handleSubmit = async (e: React.FormEvent) => {
  e.preventDefault();
  setError("");
  setLoading(true);

  try {
    const res = await login(email, password, selectedRole);

    console.log("LOGIN RESPONSE:", res);

    // 🔥 FORCE HARD REDIRECT (NOT navigate)
    if (res.firstLogin) {
      window.location.href = "/change-password"; // ✅ FIX
      return;
    }

    const role = res.role as UserRole;
    const defaultRoute = ROLE_PERMISSIONS[role].defaultRoute;

    window.location.href = defaultRoute; // ✅ FIX

  } catch (err: unknown) {
    setError(err instanceof Error ? err.message : "Login failed");
  } finally {
    setLoading(false);
  }
};



  return (
    <div className="min-h-screen flex items-center justify-center bg-background">
      <div className="w-full max-w-md">
        <div className="bg-card border border-border rounded-lg p-8">
          <div className="mb-6">
            <div className="flex items-center gap-2 mb-1">
              <div className="w-8 h-8 rounded bg-primary flex items-center justify-center">
                <span className="text-primary-foreground text-xs font-bold">V</span>
              </div>
              <h1 className="text-lg font-semibold text-foreground">VMS</h1>
            </div>
            <p className="text-sm text-muted-foreground mt-3">Vendor Management System</p>
            <p className="text-xs text-muted-foreground mt-1">Sign in to your account</p>
          </div>

          {error && (
            <div className="mb-4 p-3 bg-destructive/10 border border-destructive/20 rounded text-xs text-destructive">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-medium text-foreground mb-1.5">Email Address</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full h-9 px-3 text-sm bg-background border border-input rounded-md focus:outline-none focus:ring-1 focus:ring-ring"
                required
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-foreground mb-1.5">Password</label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full h-9 px-3 text-sm bg-background border border-input rounded-md focus:outline-none focus:ring-1 focus:ring-ring"
                required
              />
            </div>

            <p
             className="text-sm text-blue-500 cursor-pointer text-right"
            onClick={() => navigate("/forgot-password")}
            >
             Forgot Password?
            </p>
            {/* Role Selection — demo mode */}
            <div>
              <label className="block text-xs font-medium text-foreground mb-2">Sign in as (Demo)</label>
              <div className="grid grid-cols-2 gap-2">
                {ROLE_OPTIONS.map((role) => (
                  <button
                    key={role.value}
                    type="button"
                    onClick={() => setSelectedRole(role.value)}
                    className={`text-left p-2.5 rounded-md border transition-colors ${
                      selectedRole === role.value
                        ? "border-primary bg-primary/5"
                        : "border-border bg-background hover:border-muted-foreground/30"
                    }`}
                  >
                    <p className={`text-xs font-medium ${
                      selectedRole === role.value ? "text-primary" : "text-foreground"
                    }`}>
                      {role.label}
                    </p>
                    <p className="text-[10px] text-muted-foreground mt-0.5 leading-tight">{role.description}</p>
                  </button>
                ))}
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full h-9 bg-primary text-primary-foreground text-sm font-medium rounded-md hover:opacity-90 transition-opacity disabled:opacity-50"
            >
              {loading ? "Signing in..." : `Sign In as ${ROLE_OPTIONS.find(r => r.value === selectedRole)?.label}`}
            </button>
          </form>

          <p className="mt-4 text-xs text-muted-foreground text-center">
            Demo mode — select a role to preview different access levels
          </p>
        </div>
      </div>
    </div>
  );
}
