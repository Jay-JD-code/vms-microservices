import { useAuth } from "@/hooks/useAuth";
import { ShieldX } from "lucide-react";
import { useNavigate } from "react-router-dom";

export default function Unauthorized() {
  const { user, getDefaultRoute, logout } = useAuth();
  const navigate = useNavigate();

  return (
    <div className="min-h-screen flex items-center justify-center bg-background">
      <div className="text-center max-w-sm">
        <div className="w-12 h-12 rounded-full bg-destructive/10 flex items-center justify-center mx-auto mb-4">
          <ShieldX size={24} className="text-destructive" />
        </div>
        <h1 className="text-lg font-semibold text-foreground mb-2">Access Denied</h1>
        <p className="text-sm text-muted-foreground mb-1">
          You don't have permission to access this page.
        </p>
        {user && (
          <p className="text-xs text-muted-foreground mb-6">
            Signed in as <span className="font-medium text-foreground">{user.name}</span> ({user.role})
          </p>
        )}
        <div className="flex gap-2 justify-center">
          <button
            onClick={() => navigate(getDefaultRoute())}
            className="h-8 px-4 bg-primary text-primary-foreground text-xs font-medium rounded-md hover:opacity-90"
          >
            Go to Dashboard
          </button>
          <button
            onClick={logout}
            className="h-8 px-4 bg-muted text-muted-foreground text-xs font-medium rounded-md hover:bg-muted/80"
          >
            Sign Out
          </button>
        </div>
      </div>
    </div>
  );
}
