import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import AppLayout from "@/components/layout/AppLayout";
import { performanceApi, vendorApi } from "@/lib/api";
import { BarChart3, RefreshCw, Loader2 } from "lucide-react";
import { toast } from "sonner";

function ScoreBar({ label, score }: { label: string; score: number }) {
  const safeScore = score ?? 0;

  const getColor = (s: number) => {
    if (s >= 90) return "bg-green-500";
    if (s >= 75) return "bg-yellow-500";
    return "bg-red-500";
  };

  return (
    <div className="flex items-center gap-3">
      <span className="text-xs text-muted-foreground w-24">{label}</span>

      <div className="flex-1 h-2 bg-gray-200 rounded-full">
        <div
          className={`${getColor(safeScore)} h-full rounded-full`}
          style={{ width: `${safeScore}%` }}
        />
      </div>

      <span className="text-xs font-medium w-10 text-right">
        {safeScore}%
      </span>
    </div>
  );
}

export default function Performance() {
  const queryClient = useQueryClient();

  //////////////////////////////////////////////////////
  // 🔥 AUTO LOAD + AUTO CALCULATE
  //////////////////////////////////////////////////////
  const { data: reviewsData = [], isLoading } = useQuery({
    queryKey: ["performance"],
    queryFn: async () => {
      const data = await performanceApi.getAll();

      // 🔥 IF EMPTY → CALCULATE
      if (!data || data.length === 0) {
        console.log("No performance data → calculating...");

        const vendors = await vendorApi.getAll();

        await Promise.all(
          vendors.map((v: any) =>
            performanceApi.calculate(v.id)
          )
        );

        return performanceApi.getAll();
      }

      return data;
    },
    retry: 1,
  });

  //////////////////////////////////////////////////////
  // SAFE NORMALIZATION
  //////////////////////////////////////////////////////
  const reviews = reviewsData.map((r: any) => ({
    ...r,
    deliveryScore: r.deliveryScore ?? 0,
    qualityScore: r.qualityScore ?? 0,
    complianceScore: r.complianceScore ?? 0,
    overallScore: r.overallScore ?? 0,
  }));

  //////////////////////////////////////////////////////
  // RECALCULATE BUTTON
  //////////////////////////////////////////////////////
  const recalcMutation = useMutation({
    mutationFn: (vendorId: string) =>
      performanceApi.calculate(vendorId),
    onSuccess: () => {
      toast.success("Performance recalculated");
      queryClient.invalidateQueries({ queryKey: ["performance"] });
    },
    onError: () => {
      toast.error("Recalculation failed");
    },
  });

  //////////////////////////////////////////////////////
  // SUMMARY CALCULATIONS
  //////////////////////////////////////////////////////
  const avgScore =
    reviews.length > 0
      ? (
          reviews.reduce((s, p) => s + p.overallScore, 0) /
          reviews.length
        ).toFixed(1)
      : "0";

  const topPerformer =
    reviews.length > 0
      ? [...reviews].sort(
          (a, b) => b.overallScore - a.overallScore
        )[0]
      : null;

  //////////////////////////////////////////////////////
  // UI
  //////////////////////////////////////////////////////
  return (
    <AppLayout
      title="Vendor Performance"
      subtitle="Performance metrics and scorecards"
    >
      {isLoading && (
        <div className="flex items-center gap-2 mb-4 text-sm text-gray-500">
          <Loader2 size={16} className="animate-spin" />
          Loading performance...
        </div>
      )}

      {/* SUMMARY */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
        <div className="bg-white border p-4 rounded shadow-sm">
          <p className="text-xs text-gray-500 mb-1">Avg. Score</p>
          <p className="text-xl font-semibold">{avgScore}%</p>
        </div>

        <div className="bg-white border p-4 rounded shadow-sm">
          <p className="text-xs text-gray-500 mb-1">Top Performer</p>
          <p className="text-sm font-semibold">
            {topPerformer?.vendorName || "—"}
          </p>
        </div>

        <div className="bg-white border p-4 rounded shadow-sm">
          <p className="text-xs text-gray-500 mb-1">Vendors Reviewed</p>
          <p className="text-xl font-semibold">{reviews.length}</p>
        </div>
      </div>

      {/* EMPTY STATE */}
      {reviews.length === 0 && !isLoading && (
        <div className="text-center text-gray-500 mt-10">
          No performance data available
        </div>
      )}

      {/* PERFORMANCE CARDS */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {reviews.map((review: any, index: number) => {
          const overall = review.overallScore;

          return (
            <div
              key={`${review.vendorId ?? "v"}-${index}`}
              className="bg-white border rounded shadow-sm"
            >
              <div className="flex justify-between items-center p-4 border-b">
                <div>
                  <h3 className="font-semibold text-sm">
                    {review.vendorName || "Unknown Vendor"}
                  </h3>
                  <p className="text-xs text-gray-500">
                    Last updated: {review.calculatedAt || "—"}
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <span className="text-lg font-bold">
                    {overall.toFixed(1)}
                  </span>

                  <button
                    onClick={() =>
                      recalcMutation.mutate(review.vendorId)
                    }
                    className="p-1 hover:bg-gray-100 rounded"
                  >
                    <RefreshCw size={14} />
                  </button>
                </div>
              </div>

              <div className="p-4 space-y-3">
                <ScoreBar label="Delivery" score={review.deliveryScore} />
                <ScoreBar label="Quality" score={review.qualityScore} />
                <ScoreBar label="Compliance" score={review.complianceScore} />
              </div>
            </div>
          );
        })}
      </div>
    </AppLayout>
  );
}