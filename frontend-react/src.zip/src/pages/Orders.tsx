import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import AppLayout from "@/components/layout/AppLayout";
import StatusBadge from "@/components/StatusBadge";
import { orderApi, vendorApi } from "@/lib/api";
import type { OrderStatus } from "@/types";
import { useAuth } from "@/hooks/useAuth";
import { toast } from "sonner";

//////////////////////////////////////////////////////
// ✅ VALID TRANSITIONS (STRICT)
//////////////////////////////////////////////////////

const ORDER_TRANSITIONS: Record<string, string[]> = {
  CREATED: ["APPROVED", "CANCELLED"],
  APPROVED: ["SHIPPED", "CANCELLED"],
  SHIPPED: ["DELIVERED"],
  DELIVERED: ["COMPLETED"],
};

export default function Orders() {
  const { canManageVendors } = useAuth();
  const queryClient = useQueryClient();

  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<OrderStatus | "ALL">("ALL");

  const [open, setOpen] = useState(false);
  const [vendorId, setVendorId] = useState("");

  const [items, setItems] = useState([
    { productName: "", quantity: 1, price: 0 },
  ]);

  //////////////////////////////////////////////////////
  // FETCH
  //////////////////////////////////////////////////////

  const { data: ordersData = [] } = useQuery({
    queryKey: ["orders"],
    queryFn: orderApi.getAll,
  });

  const { data: vendors = [] } = useQuery({
    queryKey: ["vendors"],
    queryFn: vendorApi.getAll,
  });

  //////////////////////////////////////////////////////
  // NORMALIZE
  //////////////////////////////////////////////////////

  const orders = ordersData.map((o: any) => ({
    ...o,
    items: o.items || [],
    totalAmount: o.totalAmount ?? 0,
  }));

  //////////////////////////////////////////////////////
  // CREATE ORDER
  //////////////////////////////////////////////////////

  const createMutation = useMutation({
    mutationFn: () =>
      orderApi.create({
        vendorId,
        items,
      }),

    onSuccess: async (newOrder: any) => {
      toast.success("Order created");

      queryClient.setQueryData(["orders"], (old: any) => {
        const existing = Array.isArray(old) ? old : [];

        return [
          ...existing,
          {
            id: newOrder?.id ?? Date.now(),
            vendorId,
            vendorName:
              vendors.find((v: any) => v.id === vendorId)?.companyName || "—",
            status: "CREATED",
            items,
            totalAmount: items.reduce(
              (sum, i) => sum + (i.quantity || 0) * (i.price || 0),
              0
            ),
          },
        ];
      });

      await queryClient.invalidateQueries({ queryKey: ["orders"] });

      setOpen(false);
      setVendorId("");
      setItems([{ productName: "", quantity: 1, price: 0 }]);
    },

    onError: (err: Error) =>
      toast.error(err.message || "Failed to create order"),
  });

  //////////////////////////////////////////////////////
  // STATUS UPDATE (🔥 FIXED)
  //////////////////////////////////////////////////////

  const statusMutation = useMutation({
    mutationFn: ({ id, status }: { id: number; status: string }) =>
      orderApi.updateStatus(id, status),

    onMutate: async ({ id, status }) => {
      await queryClient.cancelQueries({ queryKey: ["orders"] });

      const previousOrders = queryClient.getQueryData(["orders"]);

      queryClient.setQueryData(["orders"], (old: any) =>
        (old || []).map((o: any) =>
          o.id === id ? { ...o, status } : o
        )
      );

      return { previousOrders };
    },

    onError: (err: any, _vars, context) => {
      queryClient.setQueryData(["orders"], context?.previousOrders);

      toast.error(
        err?.response?.data?.message || "Invalid status transition"
      );
    },

    onSuccess: async () => {
      toast.success("Order updated");
      await queryClient.invalidateQueries({ queryKey: ["orders"] });
    },
  });

  //////////////////////////////////////////////////////
  // FILTER
  //////////////////////////////////////////////////////

  const filtered = orders.filter((o: any) => {
    const matchSearch =
      o.vendorName?.toLowerCase().includes(search.toLowerCase()) ||
      String(o.id).includes(search);

    const matchStatus =
      statusFilter === "ALL" || o.status === statusFilter;

    return matchSearch && matchStatus;
  });

  //////////////////////////////////////////////////////
  // ITEM HANDLERS
  //////////////////////////////////////////////////////

  const addItem = () =>
    setItems([...items, { productName: "", quantity: 1, price: 0 }]);

  const removeItem = (index: number) =>
    setItems(items.filter((_, i) => i !== index));

  const updateItem = (index: number, field: string, value: any) => {
    const updated = [...items];
    updated[index][field] = value;
    setItems(updated);
  };

  //////////////////////////////////////////////////////
  // UI
  //////////////////////////////////////////////////////

  return (
    <AppLayout title="Purchase Orders" subtitle="Track and manage orders">
      
      {/* TOP BAR */}
      <div className="flex justify-between mb-4">
        <div className="flex gap-2">
          <input
            className="border px-2 py-1 rounded text-sm"
            placeholder="Search..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />

          <select
            className="border px-2 py-1 rounded text-sm"
            value={statusFilter}
            onChange={(e) =>
              setStatusFilter(e.target.value as OrderStatus | "ALL")
            }
          >
            <option value="ALL">All</option>
            <option value="CREATED">Created</option>
            <option value="APPROVED">Approved</option>
            <option value="SHIPPED">Shipped</option>
            <option value="DELIVERED">Delivered</option>
            <option value="COMPLETED">Completed</option>
            <option value="CANCELLED">Cancelled</option>
          </select>
        </div>

        {canManageVendors && (
          <button
            onClick={() => setOpen(true)}
            className="bg-primary text-white px-3 py-1 rounded text-sm"
          >
            Create Order
          </button>
        )}
      </div>

      {/* TABLE */}
      <div className="bg-white border rounded shadow-sm">
        <table className="w-full text-sm">
          <thead className="bg-gray-100 text-left">
            <tr>
              <th className="p-3">Order</th>
              <th className="p-3">Vendor</th>
              <th className="p-3">Items</th>
              <th className="p-3">Amount</th>
              <th className="p-3">Status</th>
              <th className="p-3">Actions</th>
            </tr>
          </thead>

          <tbody>
            {filtered.map((order: any) => {
              const transitions =
                ORDER_TRANSITIONS[order.status] || [];

              return (
                <tr key={order.id} className="border-t">
                  <td className="p-3">PO-{order.id}</td>
                  <td className="p-3">{order.vendorName || "—"}</td>
                  <td className="p-3">{order.items.length}</td>
                  <td className="p-3">
                    ${order.totalAmount.toLocaleString()}
                  </td>
                  <td className="p-3">
                    <StatusBadge status={order.status} />
                  </td>

                  {/* 🔥 ACTIONS FIXED */}
                  <td className="p-3 flex gap-1">
                    {transitions.length > 0 &&
                      transitions.map((s) => (
                        <button
                          key={`${order.id}-${s}`}
                          onClick={() =>
                            statusMutation.mutate({
                              id: order.id,
                              status: s,
                            })
                          }
                          disabled={statusMutation.isPending}
                          className="text-xs bg-gray-200 px-2 py-1 rounded disabled:opacity-50"
                        >
                          {s}
                        </button>
                      ))}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>

        {filtered.length === 0 && (
          <div className="p-4 text-center text-gray-500">
            No orders found
          </div>
        )}
      </div>

      {/* MODAL */}
      {open && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center">
          <div className="bg-white p-6 rounded w-[500px] shadow-lg">
            <h2 className="text-lg font-semibold mb-4">
              Create Order
            </h2>

            <select
              className="border w-full p-2 mb-4"
              value={vendorId}
              onChange={(e) => setVendorId(e.target.value)}
            >
              <option value="">Select Vendor</option>
              {vendors.map((v: any) => (
                <option key={v.id} value={v.id}>
                  {v.companyName}
                </option>
              ))}
            </select>

            <div className="space-y-3 mb-4">
              {items.map((item, index) => (
                <div key={index} className="flex gap-2">
                  <input
                    placeholder="Product"
                    className="border p-2 flex-1"
                    value={item.productName}
                    onChange={(e) =>
                      updateItem(index, "productName", e.target.value)
                    }
                  />

                  <input
                    type="number"
                    className="border p-2 w-20"
                    value={item.quantity}
                    onChange={(e) =>
                      updateItem(index, "quantity", Number(e.target.value))
                    }
                  />

                  <input
                    type="number"
                    className="border p-2 w-24"
                    value={item.price}
                    onChange={(e) =>
                      updateItem(index, "price", Number(e.target.value))
                    }
                  />

                  <button
                    onClick={() => removeItem(index)}
                    className="text-red-500"
                  >
                    ✕
                  </button>
                </div>
              ))}
            </div>

            <button onClick={addItem} className="text-blue-600 mb-4">
              + Add Item
            </button>

            <div className="mb-4 font-medium">
              Total: $
              {items
                .reduce((sum, i) => sum + i.quantity * i.price, 0)
                .toLocaleString()}
            </div>

            <button
              onClick={() => createMutation.mutate()}
              className="bg-primary text-white px-3 py-2 rounded w-full"
            >
              Create Order
            </button>

            <button
              onClick={() => setOpen(false)}
              className="mt-2 text-gray-500 w-full"
            >
              Cancel
            </button>
          </div>
        </div>
      )}
    </AppLayout>
  );
}