const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || "http://localhost:8080";

async function request<T>(path: string, options?: RequestInit): Promise<T> {
  const token = localStorage.getItem("vms_token");

  const headers: Record<string, string> = {
    ...(options?.headers as Record<string, string>),
  };

  if (token) {
    headers["Authorization"] = `Bearer ${token}`;
  }

  if (!(options?.body instanceof FormData)) {
    headers["Content-Type"] = "application/json";
  }

  const res = await fetch(`${API_BASE_URL}${path}`, {
    ...options,
    headers,
  });

  if (!res.ok) {
    const error = await res.text().catch(() => "Request failed");
    throw new Error(error);
  }

  if (res.status === 204) return undefined as T;

  const text = await res.text();
  return text ? JSON.parse(text) : undefined;
}

//////////////////////////////////////////////////////
// TYPES
//////////////////////////////////////////////////////

export interface DashboardResponse {
  stats: {
    vendors: number;
    orders: number;
    payments: number;
    performance: number;
  };
  vendorStatus: {
    status: string;
    value: number;
  }[];
  paymentStatus: {
    status: string;
    value: number;
  }[];
  ordersTrend: {
    month: string;
    orders: number;
  }[];
}

//////////////////////////////////////////////////////
// AUTH
//////////////////////////////////////////////////////

export const authApi = {
 login: (email: string, password: string) =>
  request<{
    firstLogin: any;
    accessToken: string;
    refreshToken: string;
    role: string;
  }>("/api/auth/login", {
    method: "POST",
    body: JSON.stringify({ email, password }),
  }),
  

  register: (data: { email: string; password: string; name: string }) =>
    request("/api/auth/register", {
      method: "POST",
      body: JSON.stringify(data),
    }),
};

//////////////////////////////////////////////////////
// VENDORS
//////////////////////////////////////////////////////

export const vendorApi = {
  getAll: () => request<any[]>("/api/vendors"),

  getById: (id: string) => request<any>(`/api/vendors/${id}`),

  create: (data: any) =>
    request("/api/vendors", {
      method: "POST",
      body: JSON.stringify(data),
    }),

  approve: (id: string) =>
    request(`/api/vendors/${id}/approve`, { method: "PUT" }),

  reject: (id: string) =>
    request(`/api/vendors/${id}/reject`, { method: "PUT" }),

  suspend: (id: string) =>
    request(`/api/vendors/${id}/suspend`, { method: "PUT" }),
};

//////////////////////////////////////////////////////
// ORDERS
//////////////////////////////////////////////////////

export const orderApi = {
  getAll: () => request<any[]>("/api/orders"),

  getById: (id: number) => request<any>(`/api/orders/${id}`),

  create: (data: any) =>
    request("/api/orders", {
      method: "POST",
      body: JSON.stringify(data),
    }),

  getByVendor: (vendorId: string, status?: string, page = 0, size = 10) => {
    const params = new URLSearchParams({
      page: String(page),
      size: String(size),
    });

    if (status) params.set("status", status);

    return request<any[]>(`/api/orders/vendor/${vendorId}?${params}`);
  },

  updateStatus: (id: number, status: string) =>
    request(`/api/orders/${id}/status?status=${status}`, {
      method: "PUT",
    }),
};

//////////////////////////////////////////////////////
// PAYMENTS
//////////////////////////////////////////////////////

export const paymentApi = {
  getAll: () => request<any[]>("/api/payments"),

  create: (data: any) =>
    request("/api/payments", {
      method: "POST",
      body: JSON.stringify(data),
    }),

  updateStatus: (id: number, status: string) =>
    request(`/api/payments/${id}/status?status=${status}`, {
      method: "PUT",
    }),

  getByVendor: (vendorId: string) =>
    request<any[]>(`/api/payments/vendor/${vendorId}`),
};

//////////////////////////////////////////////////////
// DOCUMENTS (UPDATED FOR AWS S3)
//////////////////////////////////////////////////////

export const documentApi = {
  // ✅ Get all
  getAll: () => request<any[]>("/api/documents"),

  // ✅ Your actual endpoint (KEEP THIS)
  getUploadUrl: (data: {
    fileName: string;
    contentType: string;
    vendorId: string;
    docType: string;
  }) =>
    request<{
      uploadUrl: string;
      fileKey: string;
    }>("/api/documents/upload", {
      method: "POST",
      body: JSON.stringify(data),
    }),

  // ✅ Save metadata (CRITICAL STEP)
  saveMetadata: (data: {
    vendorId: string;
    docType: string;
    fileName: string;
    fileKey: string;
  }) =>
    request("/api/documents", {
      method: "POST",
      body: JSON.stringify(data),
    }),

    approve: (id: string) =>
  request(`/api/documents/${id}/approve`, {
    method: "PUT",
  }),

reject: (id: string) =>
  request(`/api/documents/${id}/reject`, {
    method: "PUT",
  }),

  // ✅ Download
  download: async (id: number) => {
    const token = localStorage.getItem("vms_token");

    return fetch(`${API_BASE_URL}/api/documents/${id}/download`, {
      headers: token ? { Authorization: `Bearer ${token}` } : {},
    });
  },
};



//////////////////////////////////////////////////////
// PERFORMANCE
//////////////////////////////////////////////////////

export const performanceApi = {
  getAll: () => request<any[]>("/api/performance"),

  calculate: (vendorId: string) =>
    request(`/api/performance/calculate/${vendorId}`, {
      method: "POST",
    }),

  get: (vendorId: string) =>
    request<any>(`/api/performance/${vendorId}`),
};

//////////////////////////////////////////////////////
// DASHBOARD
//////////////////////////////////////////////////////

export const dashboardApi = {
  getStats: () => request<DashboardResponse>("/api/dashboard"),
};