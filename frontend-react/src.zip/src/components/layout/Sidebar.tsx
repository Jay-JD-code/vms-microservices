import { NavLink, useLocation } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import { ROLE_PERMISSIONS } from "@/types";
import type { UserRole } from "@/types";
import {
  LayoutDashboard,
  Users,
  ShoppingCart,
  CreditCard,
  FileText,
  BarChart3,
  LogOut,
  ChevronLeft,
  Menu,
  type LucideIcon,
} from "lucide-react";
import { useState } from "react";

const allNavItems: { path: string; label: string; icon: LucideIcon }[] = [
  { path: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { path: "/vendors", label: "Vendors", icon: Users },
  { path: "/orders", label: "Purchase Orders", icon: ShoppingCart },
  { path: "/payments", label: "Payments", icon: CreditCard },
  { path: "/documents", label: "Documents", icon: FileText },
  { path: "/performance", label: "Performance", icon: BarChart3 },
];

export default function Sidebar() {
  const { logout, user } = useAuth();
  const location = useLocation();
  const [collapsed, setCollapsed] = useState(false);

  const role = (user?.role || "ADMIN") as UserRole;
  const perms = ROLE_PERMISSIONS[role];
  const navItems = allNavItems.filter((item) =>
    perms.allowedRoutes.some((r) => item.path.startsWith(r))
  );

  return (
    <aside
      className={`flex flex-col bg-sidebar text-sidebar-foreground border-r border-sidebar-border transition-all duration-200 ${
        collapsed ? "w-16" : "w-60"
      }`}
    >
      {/* Header */}
      <div className="flex items-center justify-between h-14 px-4 border-b border-sidebar-border">
        {!collapsed && (
          <span className="text-sm font-semibold text-sidebar-primary tracking-wide">
            VMS
          </span>
        )}
        <button
          onClick={() => setCollapsed(!collapsed)}
          className="p-1 rounded hover:bg-sidebar-accent text-sidebar-muted"
        >
          {collapsed ? <Menu size={18} /> : <ChevronLeft size={18} />}
        </button>
      </div>

      {/* Navigation */}
      <nav className="flex-1 py-2 overflow-y-auto">
        {navItems.map((item) => {
          const isActive = location.pathname.startsWith(item.path);
          return (
            <NavLink
              key={item.path}
              to={item.path}
              className={`flex items-center gap-3 px-4 py-2.5 mx-2 rounded text-sm transition-colors ${
                isActive
                  ? "bg-sidebar-accent text-sidebar-accent-foreground font-medium"
                  : "text-sidebar-foreground hover:bg-sidebar-accent/60 hover:text-sidebar-accent-foreground"
              }`}
              title={collapsed ? item.label : undefined}
            >
              <item.icon size={18} className="shrink-0" />
              {!collapsed && <span>{item.label}</span>}
            </NavLink>
          );
        })}
      </nav>

      {/* Footer */}
      <div className="border-t border-sidebar-border p-3">
        {!collapsed && user && (
          <div className="mb-2 px-1">
            <p className="text-xs font-medium text-sidebar-primary truncate">{user.name}</p>
            <p className="text-xs text-sidebar-muted truncate">{user.email}</p>
            <span className="inline-block mt-1 px-1.5 py-0.5 text-[10px] font-medium rounded bg-sidebar-accent text-sidebar-accent-foreground uppercase tracking-wider">
              {perms.label}
            </span>
          </div>
        )}
        <button
          onClick={logout}
          className="flex items-center gap-3 w-full px-2 py-2 rounded text-sm text-sidebar-muted hover:bg-sidebar-accent hover:text-sidebar-accent-foreground transition-colors"
          title="Sign out"
        >
          <LogOut size={18} className="shrink-0" />
          {!collapsed && <span>Sign Out</span>}
        </button>
      </div>
    </aside>
  );
}
