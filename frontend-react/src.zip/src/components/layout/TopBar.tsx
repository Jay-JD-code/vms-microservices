import { useAuth } from "@/hooks/useAuth";
import { ROLE_PERMISSIONS } from "@/types";
import type { UserRole } from "@/types";
import { Bell, Search } from "lucide-react";

interface TopBarProps {
  title: string;
  subtitle?: string;
}

export default function TopBar({ title, subtitle }: TopBarProps) {
  const { user } = useAuth();

  return (
    <header className="h-14 border-b border-border bg-card flex items-center justify-between px-6 shrink-0">
      <div>
        <h1 className="text-sm font-semibold text-foreground">{title}</h1>
        {subtitle && <p className="text-xs text-muted-foreground">{subtitle}</p>}
      </div>
      <div className="flex items-center gap-4">
        <div className="relative hidden md:block">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <input
            type="text"
            placeholder="Search..."
            className="h-8 pl-9 pr-3 text-xs bg-muted border-none rounded-md w-52 focus:outline-none focus:ring-1 focus:ring-ring"
          />
        </div>
        <button className="relative p-2 rounded-md hover:bg-muted text-muted-foreground">
          <Bell size={16} />
          <span className="absolute top-1.5 right-1.5 w-1.5 h-1.5 bg-destructive rounded-full" />
        </button>
        <div className="flex items-center gap-2 pl-3 border-l border-border">
          <div className="w-7 h-7 rounded-full bg-primary flex items-center justify-center text-primary-foreground text-xs font-medium">
            {user?.name?.charAt(0) || "A"}
          </div>
          <div className="hidden md:block">
            <span className="text-xs font-medium text-foreground">{user?.name}</span>
            <span className="ml-1.5 text-[10px] px-1.5 py-0.5 rounded bg-muted text-muted-foreground font-medium uppercase">
              {user?.role ? ROLE_PERMISSIONS[user.role as UserRole]?.label || user.role : ""}
            </span>
          </div>
        </div>
      </div>
    </header>
  );
}
