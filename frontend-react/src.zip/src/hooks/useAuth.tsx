import { createContext, useContext, useState, useCallback, type ReactNode } from "react";
import { type AuthUser, type UserRole, ROLE_PERMISSIONS } from "@/types";

//////////////////////////////////////////////////////
// TYPES
//////////////////////////////////////////////////////

type LoginResult = {
  role: string;
  firstLogin: boolean;
};

interface AuthState {
  user: (AuthUser & { firstLogin?: boolean }) | null;
  token: string | null;
  isAuthenticated: boolean;
  login: (email: string, password: string, demoRole?: UserRole) => Promise<LoginResult>;
  logout: () => void;
  hasRouteAccess: (route: string) => boolean;
  canApproveVendors: boolean;
  canProcessPayments: boolean;
  canManageVendors: boolean;
  canViewAllData: boolean;
  getDefaultRoute: () => string;
}

const AuthContext = createContext<AuthState | null>(null);

//////////////////////////////////////////////////////
// DEMO USERS
//////////////////////////////////////////////////////

const DEMO_USERS: Record<UserRole, AuthUser> = {
  ADMIN: { id: "1", email: "admin@vms.com", name: "Admin User", role: "ADMIN" },
  VENDOR: { id: "2", email: "vendor@acme.com", name: "John Smith", role: "VENDOR" },
  PROCUREMENT: { id: "3", email: "procurement@vms.com", name: "Sarah Chen", role: "PROCUREMENT" },
  FINANCE: { id: "4", email: "finance@vms.com", name: "Mike Johnson", role: "FINANCE" },
};

//////////////////////////////////////////////////////
// STORAGE HELPERS
//////////////////////////////////////////////////////

function getStoredUser(): (AuthUser & { firstLogin?: boolean }) | null {
  try {
    const stored = localStorage.getItem("vms_user");
    if (!stored || stored === "undefined") return null;
    return JSON.parse(stored);
  } catch {
    console.error("Invalid user in localStorage");
    return null;
  }
}

function getStoredToken(): string | null {
  const t = localStorage.getItem("vms_token");
  return t && t !== "undefined" ? t : null;
}

function getPerms(user: AuthUser | null) {
  if (!user) return ROLE_PERMISSIONS.VENDOR;
  return ROLE_PERMISSIONS[user.role] || ROLE_PERMISSIONS.VENDOR;
}

//////////////////////////////////////////////////////
// PROVIDER
//////////////////////////////////////////////////////

export function AuthProvider({ children }: { children: ReactNode }) {

  const [user, setUser] = useState<(AuthUser & { firstLogin?: boolean }) | null>(getStoredUser);
  const [token, setToken] = useState<string | null>(getStoredToken);

  //////////////////////////////////////////////////////
  // LOGIN
  //////////////////////////////////////////////////////

  const login = useCallback(async (email: string, password: string, demoRole?: UserRole): Promise<LoginResult> => {
    try {
      const { authApi } = await import("@/lib/api");

      const res = await authApi.login(email, password);

      const token = res.accessToken;

      const user = {
        id: email,
        email,
        name: email,
        role: res.role as UserRole,
        firstLogin: res.firstLogin,
      };

      setToken(token);
      setUser(user);

      localStorage.setItem("vms_token", token);
      localStorage.setItem("vms_user", JSON.stringify(user));

      return {
        role: res.role,
        firstLogin: res.firstLogin,
      };

    } catch (err: any) {
      console.warn("Backend login failed:", err.message);

      if (demoRole) {
        const demoUser = {
          ...DEMO_USERS[demoRole],
          firstLogin: false,
        };

        const demoToken = `demo-${demoRole.toLowerCase()}`;

        setToken(demoToken);
        setUser(demoUser);

        localStorage.setItem("vms_token", demoToken);
        localStorage.setItem("vms_user", JSON.stringify(demoUser));

        return {
          role: demoRole,
          firstLogin: false,
        };
      }

      throw new Error(err.message || "Invalid credentials");
    }
  }, []);

  //////////////////////////////////////////////////////
  // LOGOUT
  //////////////////////////////////////////////////////

  const logout = useCallback(() => {
    setUser(null);
    setToken(null);
    localStorage.removeItem("vms_token");
    localStorage.removeItem("vms_user");
  }, []);

  //////////////////////////////////////////////////////
  // PERMISSIONS
  //////////////////////////////////////////////////////

  const perms = getPerms(user);

  const hasRouteAccess = useCallback((route: string) => {
    if (!user) return false;
    const p = ROLE_PERMISSIONS[user.role];
    if (!p) return false;
    return p.allowedRoutes.some((r) => route.startsWith(r));
  }, [user]);

  const getDefaultRoute = useCallback(() => {
    return perms.defaultRoute;
  }, [perms]);

  //////////////////////////////////////////////////////
  // PROVIDER
  //////////////////////////////////////////////////////

  return (
    <AuthContext.Provider value={{
      user,
      token,
      isAuthenticated: !!user && !!token,
      login,
      logout,
      hasRouteAccess,
      canApproveVendors: perms.canApproveVendors,
      canProcessPayments: perms.canProcessPayments,
      canManageVendors: perms.canManageVendors,
      canViewAllData: perms.canViewAllData,
      getDefaultRoute,
    }}>
      {children}
    </AuthContext.Provider>
  );
}

//////////////////////////////////////////////////////
// HOOK
//////////////////////////////////////////////////////

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}